import cv2
import numpy as np
from matplotlib import pyplot as plt
import json
import pyvista as pv

#from get_lines import obtain_shadow
from p3_2single_level import final_shadow_points

with open('calibration.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
camera_matrix=np.array(datat["camera_matrix"])
dist_coefs=np.array(datat["dist_coefs"])

with open('riusciti.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
riusciti=datat["riusciti"]

with open('contours.json', 'r') as file:
    contours = json.load(file)

with open('position.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
rvecs=np.array(datat["rotation_vectors"])
tvecs=np.array(datat["translation_vectors"])

translation_vectors=[]
rotation_matrix=[]
l=len(rvecs)
for i in range(l):
    R, _ = cv2.Rodrigues(rvecs[i])

    R_T = np.transpose(R)
    camera_position = -np.dot(R_T, tvecs[i])
    translation_vectors.append(camera_position)
    rotation_matrix.append(R_T)

translation_vectors=np.array(translation_vectors)
rotation_matrix=np.array(rotation_matrix)  

i=0
'''
l=len(riusciti)
for j in range(len(riusciti)):
    if(riusciti[j]==1):
        contours.pop(j-i)
        i=i+1
        l=l-1
'''

points=[]

for z in range(0,-2000,-5):
    ps=final_shadow_points(z,translation_vectors,rotation_matrix,contours,camera_matrix,dist_coefs,31)
    for array in ps:
        for point in array:
            #print(point)
            points.append(np.float32([point[0][0],point[0][1],z/5]))
    if(z%200==0):
        print(str(-z/20)+"% Comepleted")
        #print("% Comepleted")

print(len(points))
points=np.array(points)
data={"points":points.tolist()}
with open("points.json", "w") as f:
    json.dump(data, f)
point_cloud = pv.PolyData(points)
point_cloud.plot(eye_dome_lighting=True)

