import cv2
import numpy as np
from matplotlib import pyplot as plt
import json

def find_biggest_squares(binary_image, min_area=1000, max_area2=10000000, epsilon_factor=0.04):
    """
    descrizione non corretta
    Finds distorted squares (quadrilaterals) in a binarized image.
    
    Args:
        binary_image: A single-channel, 8-bit binarized image (numpy array).
        min_area: Minimum area of the contour to be considered (filters noise).
        epsilon_factor: Controls how loosely the contour is approximated. 
                        Higher = ignores more distortion.
                        
    Returns:
        A list of numpy arrays, where each array contains the 4 (x,y) coordinates 
        of a detected square's corners.
    """
    # 1. Find the contours of the objects
    # RETR_EXTERNAL gets only the outer edges, CHAIN_APPROX_SIMPLE compresses the data
    contours, _ = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    '''
    cv2.drawContours(img, contours, -1, (0, 255, 0), 3)
    plt.imshow(img)
    plt.show()
    '''
    max_area=0
    square=0
    
    for contour in contours:
        # 2. Ignore tiny specks of noise
        area=cv2.contourArea(contour)
        #print (area)
        if area < min_area or area < max_area or area >max_area2:
            continue
            
        # 3. Approximate the contour to a polygon
        # arcLength calculates the perimeter. 
        perimeter = cv2.arcLength(contour, True)
        
        # Epsilon is the maximum distance from contour to approximated contour.
        # It is usually set to a percentage of the perimeter (e.g., 2% to 5%).
        epsilon = epsilon_factor * perimeter
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # 4. If the approximated shape has 4 points, it's a quadrilateral
        if len(approx) == 4:
            # 5. Ensure it is convex (no inward-bending sides)
            if cv2.isContourConvex(approx):
                square=approx
                max_area=area
    r=[square]       
    return r

def riduci_square(square, l=700):
    dir1=square[0,0]-square[2,0]
    print(dir1)
    dir2=square[1,0]-square[3,0]
    n1=np.linalg.norm(dir1)
    n2=np.linalg.norm(dir2)
    dir1=dir1/n1
    dir2=dir2/n2
    sq=square.copy()
    sq[0,0]=square[0,0]-l*dir1
    sq[2,0]=square[2,0]+l*dir1
    sq[1,0]=square[1,0]-l*dir2
    sq[3,0]=square[3,0]+l*dir2
    return sq

def mask_outside_polygon(img, approx):
    # 1. Create a black mask with the same dimensions as the image
    # We use shape[:2] to get height and width. dtype=np.uint8 is crucial.
    mask = np.zeros(img.shape[:2], dtype=np.uint8)

    # 2. Draw the filled polygon on the mask
    # [approx] is the list of points
    # -1 tells OpenCV to draw all contours in the list
    # 255 is the color (white)
    # -1 as the last argument indicates we want to FILL the polygon
    cv2.drawContours(mask, [approx], -1, 255, -1)

    # 3. Apply the mask to the original image
    # This keeps the image where the mask is white, and makes it black elsewhere
    result = cv2.bitwise_and(img, img, mask=mask)
    
    return result

def find_edges(gray, treshold=10, scale=1, delta=0, ddepth=cv2.CV_16S):

    grad_x = cv2.Sobel(gray, ddepth, 1, 0, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)
    grad_y = cv2.Sobel(gray, ddepth, 0, 1, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)

    abs_grad_x = cv2.convertScaleAbs(grad_x)
    abs_grad_y = cv2.convertScaleAbs(grad_y)

    grad = cv2.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)
    sobel_8u = np.uint8(np.clip(grad, 0, 255))
    _, binary_edges = cv2.threshold(sobel_8u, treshold, 255, cv2.THRESH_BINARY)
    return binary_edges


def obtain_border(img, scale=1, delta=0, ddepth=cv2.CV_16S, kernel_dimension=13):

    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    rett, thresh = cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    red=img[:,:,2]
    rett, thresh2 = cv2.threshold(red,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

    binary_edges=find_edges(gray, treshold=20, scale=scale, delta=delta, ddepth=ddepth)
    square=find_biggest_squares(binary_edges)
    print (square)
    sq=[riduci_square(square[0],l=300)]#parametro parametrizzabile
    res=mask_outside_polygon(thresh2,sq[0])

    kernel=np.ones((kernel_dimension,kernel_dimension),np.uint8)
    img2=cv2.erode(res, kernel)
    kernel = np.ones((30,30),np.uint8)#parametro parametrizzabile
    kernel2 = np.ones((100,100),np.uint8)#parametro parametrizzabile
    closing = cv2.morphologyEx(img2, cv2.MORPH_CLOSE, kernel)
    dilation = cv2.dilate(closing,kernel2,iterations = 1)
    #plt.imshow(dilation)
    #plt.show()

    #binary_edges=find_edges(gray,scale=scale, delta=delta, ddepth=ddepth)
    #plt.imshow(binary_edges)
    #plt.show()
    dilation=np.uint8(dilation)
    final=cv2.bitwise_and(binary_edges,binary_edges,mask=dilation)
    contours, hierarchy = cv2.findContours(final, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    k=0
    max=0
    i=0
    for el in contours:
        l=contours[i].shape[0]
        if(l>max):
            max=l
            k=i
        i=i+1
    cnt=contours[k]

    epsilon = 0.001*cv2.arcLength(cnt,True)
    approx = cv2.approxPolyDP(cnt,epsilon,True)
    return approx
    
def show_border(approx):
    black2=np.zeros((3000,4000,1))
    white=255-black2
    r=mask_outside_polygon(white,approx)
    plt.imshow(r)
    plt.show()
    return 0








'''
scale = 1
delta = 0
ddepth = cv2.CV_16S
img_name="img2/14.jpg"


img=cv2.imread(img_name)
imgc=img
h, w = cv2.imread(img_name).shape[:2]

gray2 = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
gray=img[:,:,2]
#gray=255-gray

rett, thresh = cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
rett2, thresh2 = cv2.threshold(gray2,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

grad_x = cv2.Sobel(gray2, ddepth, 1, 0, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)
# Gradient-Y
# grad_y = cv.Scharr(gray,ddepth,0,1)
grad_y = cv2.Sobel(gray2, ddepth, 0, 1, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)


abs_grad_x = cv2.convertScaleAbs(grad_x)
abs_grad_y = cv2.convertScaleAbs(grad_y)


grad = cv2.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)
plt.imshow(grad)
plt.show()
sobel_8u = np.uint8(np.clip(grad, 0, 255))
_, binary_edges = cv2.threshold(sobel_8u, 20, 255, cv2.THRESH_BINARY)
plt.imshow(binary_edges)
plt.show()

#thresh=255-thresh

kernel = np.ones((13,13),np.uint8)
#kernel = np.ones((100,100),np.uint8)
#kernel = np.ones((5,5),np.uint8)
#kernel = np.ones((8,8),np.uint8)
img2=cv2.erode(thresh, kernel)
plt.imshow(thresh2)
plt.show()

square=find_biggest_squares(binary_edges)
#cv2.drawContours(img, square, -1, (0, 255, 0), 3)
print (square)
sq=[riduci_square(square[0],l=300)]
#cv2.drawContours(img, sq, -1, (0, 255, 0), 3)
res=mask_outside_polygon(img2,sq[0])
#plt.imshow(img)
#plt.show()


#parte appena copiata che ottiene il contorno del mouse.

#rett, thresh = cv2.threshold(res,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
#kernel = np.ones((100,100),np.uint8)
kernel = np.ones((30,30),np.uint8)
kernel2 = np.ones((100,100),np.uint8)
closing = cv2.morphologyEx(res, cv2.MORPH_CLOSE, kernel)
dilation = cv2.dilate(closing,kernel2,iterations = 1)
plt.imshow(closing)
plt.show()
contours,hierarchy = cv2.findContours(closing, 1, 2)
cnt = contours[0]
epsilon = 0.001*cv2.arcLength(cnt,True)
approx = cv2.approxPolyDP(cnt,epsilon,True)


black=np.zeros((3000,4000,3))
l=approx.shape[0]
for i in range(l-1):
    cv2.line(black,(approx[i,0,0],approx[i,0,1]),(approx[i+1,0,0],approx[i+1,0,1]),(0,255,0),2)
cv2.line(black,(approx[l-1,0,0],approx[l-1,0,1]),(approx[0,0,0],approx[0,0,1]),(0,255,0),2)


#plt.imshow(closing2, cmap='gray', vmin=0, vmax=255)
plt.imshow(black)
plt.show()

#print (approx)


grad_x = cv2.Sobel(gray, ddepth, 1, 0, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)
# Gradient-Y
# grad_y = cv.Scharr(gray,ddepth,0,1)
grad_y = cv2.Sobel(gray, ddepth, 0, 1, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)


abs_grad_x = cv2.convertScaleAbs(grad_x)
abs_grad_y = cv2.convertScaleAbs(grad_y)


grad = cv2.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)
plt.imshow(abs_grad_y)
plt.show()

sobel_8u = np.uint8(np.clip(grad, 0, 255))
#_, binary_edges = cv2.threshold(sobel_8u, 20, 255, cv2.THRESH_BINARY)
_, binary_edges = cv2.threshold(sobel_8u, 10, 255, cv2.THRESH_BINARY)
plt.imshow(binary_edges)
plt.show()
contours, hierarchy = cv2.findContours(binary_edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
black2=np.zeros((3000,4000,1))
black2=np.uint8(black2)
cv2.drawContours(black2, contours, -1, 255, 2)


dilation=np.uint8(dilation)
final=cv2.bitwise_and(binary_edges,binary_edges,mask=dilation)
plt.imshow(final)
plt.show()

#deblurred=cv2.medianBlur(final,5)
#plt.imshow(deblurred)
#plt.show()

contours, hierarchy = cv2.findContours(final, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
black=np.zeros((3000,4000,1))
cv2.drawContours(black, contours, -1, 255, 2)
plt.imshow(black)
plt.show()

k=0
max=0
i=0
for el in contours:
    l=contours[i].shape[0]
    if(l>max):
        max=l
        k=i
    i=i+1

cnt=contours[k]
print(contours)
epsilon = 0.001*cv2.arcLength(cnt,True)
approx = cv2.approxPolyDP(cnt,epsilon,True)


black=np.zeros((3000,4000,3))
l=approx.shape[0]
for i in range(l-1):
    cv2.line(black,(approx[i,0,0],approx[i,0,1]),(approx[i+1,0,0],approx[i+1,0,1]),(0,255,0),2)
cv2.line(black,(approx[l-1,0,0],approx[l-1,0,1]),(approx[0,0,0],approx[0,0,1]),(0,255,0),2)


#plt.imshow(closing2, cmap='gray', vmin=0, vmax=255)
plt.imshow(black)
plt.show()

black2=np.zeros((3000,4000,1))
white=255-black2
r=mask_outside_polygon(white,approx)
plt.imshow(r)
plt.show()
#'''


#part 2 
'''
img_name="img2/14.jpg"
img=cv2.imread(img_name)
approx=obtain_border2(img)

l=approx.shape[0]
print(l)
show_border(approx)
all_points = np.vstack(approx)
hull = cv2.convexHull(all_points)
show_border(hull)
'''
