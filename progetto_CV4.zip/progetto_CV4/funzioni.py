import numpy as np
import cv2
import math
from sklearn.cluster import KMeans
import random
lim=np.pi/8


def sgn(n):
    if (n>=0):
        return 1
    else:
        return -1

def truncate_angle(angle):
    #Attenzione: funziona solo in determinati casi
    up=np.pi/2
    down=-up
    if(angle<up and angle>down):
        return angle
    elif(angle>up):
        return angle-np.pi
    else:return angle+np.pi

def trunc_avg(val1, val2):
    a=np.pi/4
    v1=truncate_angle(val1+a)
    v2=truncate_angle(val2+a)
    return truncate_angle((v1+v2)/2-a)

def ptop_distance(p1,p2):
    p1=np.array(p1)
    p2=np.array(p2)
    d=np.linalg.norm(p1-p2)
    return d

def find_angle(p1,p2,p3,p4):
    p1=np.array(p1)
    p2=np.array(p2)
    p3=np.array(p3)
    p4=np.array(p4)
    v1=p1-p2
    v2=p3-p4
    n1=np.linalg.norm(v1)
    v1=v1/n1
    n2=np.linalg.norm(v2)
    v2=v2/n2
    #print(abs(np.dot(v1,v2)))
    return np.acos(abs(np.dot(v1,v2))*0.99)#the 0.99 serve perchè ogni tanto viene il risultato 1.00000002 per errori di approssimazione e il sistema si rompe

def find_angle_sign(p1,p2,p3,p4):
    p1=np.array(p1)
    p2=np.array(p2)
    p3=np.array(p3)
    p4=np.array(p4)
    v1=p1-p2
    v2=p3-p4
    n1=np.linalg.norm(v1)
    v1=v1/n1
    n2=np.linalg.norm(v2)
    v2=v2/n2
    #print(abs(np.dot(v1,v2)))
    return np.acos(np.dot(v1,v2)*0.99)#the 0.99 serve perchè ogni tanto viene il risultato 1.00000002 per errori di approssimazione e il sistema si rompe

def find_closest_point_on_line(p1, dir, p2):
    p1=np.array(p1)
    p2=np.array(p2)
    dir=np.array(dir)
    p2_vec = p2 - p1
    
    t = np.dot(p2_vec, dir) / np.dot(dir, dir)
    vet=dir*t
    d = np.linalg.norm(p2_vec-vet)# distanza perpendicolare alla linea
    d2= np.linalg.norm(vet)# distanza parallela alla linea da p1

    # The closest point (projection) on the line is p1 + t * line_vec
    closest_point = p1 + vet

    return closest_point, d, d2

def find_closest_point_on_line_signe(p1, dir, p2):
    p1=np.array(p1)
    p2=np.array(p2)
    dir=np.array(dir)
    p2_vec = p2 - p1
    
    t = np.dot(p2_vec, dir) / np.dot(dir, dir)
    vet=dir*t
    d = np.linalg.norm(p2_vec-vet)# distanza perpendicolare alla linea
    d2= np.linalg.norm(vet)*sgn(t)# distanza parallela alla linea da p1

    # The closest point (projection) on the line is p1 + t * line_vec
    closest_point = p1 + vet

    return closest_point, d, d2

def find_closest_point_on_line_angle(p1, dir, p2):
    p1=np.array(p1)
    p2=np.array(p2)
    dir=np.array(dir)
    p2_vec = p2 - p1
    
    t = np.dot(p2_vec, dir) / np.dot(dir, dir)
    vet=dir*t
    d = np.linalg.norm(p2_vec-vet)# distanza perpendicolare alla linea
    d2= np.linalg.norm(vet)# distanza parallela alla linea da p1

    # The closest point (projection) on the line is p1 + t * line_vec
    closest_point = p1 + vet
    angle=0
    if(d!=0):
        if(d2!=0 ):
            angle=np.atan(abs(d/d2))
            #angle=np.acos(abs( np.dot(p2_vec, dir)/np.linalg.norm(p2_vec)/np.linalg.norm(dir)))
        else: angle=np.pi/2

    return closest_point,  angle, d2

def find_closest_point_on_line_angle2(p1, dir, p2):
    p1=np.array(p1)
    p2=np.array(p2)
    dir=np.array(dir)
    p2_vec = p2 - p1
    
    t = np.dot(p2_vec, dir) / np.dot(dir, dir)
    vet=dir*t
    d = np.linalg.norm(p2_vec-vet)# distanza perpendicolare alla linea
    d2= np.linalg.norm(vet)# distanza parallela alla linea da p1

    # The closest point (projection) on the line is p1 + t * line_vec
    closest_point = p1 + vet
    angle=0
    if(d!=0):
        if(d2!=0 ):
            angle=np.atan(abs(d/d2))
            #angle=np.acos(abs( np.dot(p2_vec, dir)/np.linalg.norm(p2_vec)/np.linalg.norm(dir)))
        else: angle=np.pi/2

    d3=np.linalg.norm(p1-p2)

    return closest_point,  angle, d2, d3

def closest_point_to_lines(lines):
    '''
    lines are defined as pendenza(angolo) e sfasamento su asse y.
    '''
    angles=np.array(lines[:,0])

    points=[]
    for i in range(len(angles)):
        points.append([0,lines[i,1]])

    bases=[]
    for i in range(len(angles)):
        bases.append([np.sin(angles[i]),np.cos(angles[i])])
    
    rot=[[0,-1],[1,0]]
    bases2=[]
    for i in range(len(angles)):
        bases2.append(rot@bases[i])

    camb=[]
    for i in range(len(angles)):
        camb.append( np.linalg.inv(np.transpose([bases[i],bases2[i]])))

    lines2=[]
    mat=[]
    for i in range(len(angles)):
        line=camb[i]@points[i]
        lines2.append(-line[1])

        mat.append(camb[i,1])

    mat=np.array(mat)
    lines2=np.array(lines2)

    x=np.linalg.pinv(mat)@lines2
    return x

def distance_point_to_line_pts(x0, y0, x1, y1, x2, y2):
    """
    Calculates the distance from point (x0, y0) to the line passing through (x1, y1) and (x2, y2).
    """
    if x1 == x2 and y1 == y2:
        raise ValueError("The two points defining the line cannot be the same.")
    
    #if (x1 == x2):return x0-x1
        
    numerator = abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1)
    denominator = math.sqrt((y2 - y1)**2 + (x2 - x1)**2)
    
    return numerator / denominator

def distance_point_to_line_pts2(x0, y0, x1, y1, x2, y2):
    """
    Calculates the distance from point (x0, y0) to the line passing through (x1, y1) and (x2, y2).
    """
    if x1 == x2 and y1 == y2:
        raise ValueError("The two points defining the line cannot be the same.")
    
    #if (x1 == x2):return x0-x1
        
    numerator = abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1)
    denominator = math.sqrt((y2 - y1)**2 + (x2 - x1)**2)

    d=numerator / denominator

    p,_=find_closest_point_on_line([x1,y1],[x2-x1,y2-y1],[x0,y0])

    x4,y4=p

    if(y4-y0!=0):
        d=d*sgn(y4-y0)
    else: d=d*-sgn(x4-x0)
    
    return d


def line_plane_intersection(line_point, line_dir, plane_point, plane_normal, epsilon=1e-8):
    """
    Calculates the intersection point of a 3D line and a 3D plane.
    
    Args:
        line_point: A point on the line (e.g., [x, y, z])
        line_dir: The direction vector of the line (e.g., [dx, dy, dz])
        plane_point: A point on the plane
        plane_normal: The normal vector of the plane
        epsilon: Tolerance for floating point comparison
        
    Returns:
        The intersection point as a numpy array, or None if they don't intersect.
    """
    # Ensure inputs are numpy arrays for vector operations
    p0 = np.array(line_point, dtype=float)
    u = np.array(line_dir, dtype=float)
    p1 = np.array(plane_point, dtype=float)
    n = np.array(plane_normal, dtype=float)
    
    # Calculate the dot product of the line direction and plane normal
    dot_product = np.dot(n, u)
    
    # Check if the line is parallel to the plane
    if abs(dot_product) < epsilon:
        # Check if the line lies entirely within the plane
        # by seeing if the vector between the points is orthogonal to the normal
        if abs(np.dot(n, p1 - p0)) < epsilon:
            print("The line lies entirely within the plane.")
            return None
        else:
            print("The line is parallel to the plane and never intersects.")
            return None
            
    # Calculate the scalar t
    w = p1 - p0
    t = np.dot(n, w) / dot_product
    
    # Calculate the exact intersection coordinate
    intersection_point = p0 + t * u
    
    return intersection_point


def average_of_points(points):
    #np array expected
    l=len(points)
    r=np.array([0,0])
    for i in range(l):
        r=r+points[i]
    return r/l

