import cv2
import numpy as np
from matplotlib import pyplot as plt
import json
import pyvista as pv

with open('points.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
points=np.array(datat["points"])
point_cloud = pv.PolyData(points)
point_cloud.plot(eye_dome_lighting=True)