import cv2
import numpy as np
from matplotlib import pyplot as plt
import json

from prova_elimina_rosso2 import obtain_border
from prova_elimina_rosso2 import mask_outside_polygon

'''
This part of the code recognize where is present the object on the image and return his border for every image
It doesn't return the border but writes it on a json file 
In order to do that it calls the obtain_border function
'''

def show_border(approx):
    black2=np.zeros((3000,4000,1))
    white=255-black2
    r=mask_outside_polygon(white,approx)
    plt.imshow(r)
    plt.show()
    return 0

contours=[]
n=31
img=[]
img_names2 = ["img3/" + str(i) + ".jpg" for i in range(1,n+1)]
a_media=0
for i in range(0,n):
    imgt=cv2.imread(img_names2[i])
    approx=obtain_border(imgt)
    a=cv2.contourArea(approx)
    # In order to avoid cases when it return only the "empty border" 
    if(i>5 and a<0.5*a_media):#temporary solution there migth be better ones
        all_points = np.vstack(approx)
        approx = cv2.convexHull(all_points)
        a=cv2.contourArea(approx)
    a_media=(a_media*i+a)/(i+1)

    contours.append(approx)
    show_border(approx)

clean_list = [
    item.tolist() if isinstance(item, np.ndarray) else item 
    for item in contours
]
with open("contours.json", "w") as f:
    json.dump(clean_list, f)

'''
way to read this
with open('data.json', 'r') as file:
    loaded_list = json.load(file)

'''

