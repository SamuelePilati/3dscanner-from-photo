import cv2
import numpy as np
from matplotlib import pyplot as plt
import json

import funzioni
from funzioni import ptop_distance
from funzioni import find_angle
from funzioni import find_angle_sign
from funzioni import find_closest_point_on_line
from funzioni import find_closest_point_on_line_signe
from funzioni import find_closest_point_on_line_angle
from funzioni import find_closest_point_on_line_angle2
from funzioni import average_of_points
from prova_elimina_rosso2 import find_edges
from prova_elimina_rosso2 import mask_outside_polygon


def find_biggest_squares(binary_image, min_area=2000000, max_area2=10000000, epsilon_factor=0.04):
    """
    descrizione non corretta
    Finds distorted squares (quadrilaterals) in a binarized image.
    
    Args:
        binary_image: A single-channel, 8-bit binarized image (numpy array).
        min_area: Minimum area of the contour to be considered (filters noise).
        epsilon_factor: Controls how loosely the contour is approximated. 
                        Higher = ignores more distortion.
                        
    Returns:
        A list of numpy arrays, where each array contains the 4 (x,y) coordinates 
        of a detected square's corners.
    """
    # 1. Find the contours of the objects
    # RETR_EXTERNAL gets only the outer edges, CHAIN_APPROX_SIMPLE compresses the data
    contours, _ = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    '''
    cv2.drawContours(img, contours, -1, (0, 255, 0), 3)
    plt.imshow(img)
    plt.show()
    '''
    max_area=0
    square=0
    trovato=0
    
    for contour in contours:
        # 2. Ignore tiny specks of noise
        area=cv2.contourArea(contour)
        #print (area)
        if area < min_area or area < max_area or area >max_area2:
            continue
            
        # 3. Approximate the contour to a polygon
        # arcLength calculates the perimeter. 
        perimeter = cv2.arcLength(contour, True)
        
        # Epsilon is the maximum distance from contour to approximated contour.
        # It is usually set to a percentage of the perimeter (e.g., 2% to 5%).
        epsilon = epsilon_factor * perimeter
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # 4. If the approximated shape has 4 points, it's a quadrilateral
        if len(approx) == 4:
            # 5. Ensure it is convex (no inward-bending sides)
            if cv2.isContourConvex(approx):
                square=approx
                trovato=1
                max_area=area
    r=[square]       
    return r,trovato


def find_distorted_squares(binary_image, min_area=1000, max_area=50000, epsilon_factor=0.04):
    """
    Finds distorted squares (quadrilaterals) in a binarized image.
    
    Args:
        binary_image: A single-channel, 8-bit binarized image (numpy array).
        min_area: Minimum area of the contour to be considered (filters noise).
        epsilon_factor: Controls how loosely the contour is approximated. 
                        Higher = ignores more distortion.
                        
    Returns:
        A list of numpy arrays, where each array contains the 4 (x,y) coordinates 
        of a detected square's corners.
    """
    # 1. Find the contours of the objects
    # RETR_EXTERNAL gets only the outer edges, CHAIN_APPROX_SIMPLE compresses the data
    contours, _ = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    '''
    cv2.drawContours(img, contours, -1, (0, 255, 0), 3)
    plt.imshow(img)
    plt.show()
    '''
    squares = []
    
    for contour in contours:
        # 2. Ignore tiny specks of noise
        area=cv2.contourArea(contour)
        #print (area)
        if area < min_area or area > max_area:
            continue
            
        # 3. Approximate the contour to a polygon
        # arcLength calculates the perimeter. 
        perimeter = cv2.arcLength(contour, True)
        
        # Epsilon is the maximum distance from contour to approximated contour.
        # It is usually set to a percentage of the perimeter (e.g., 2% to 5%).
        epsilon = epsilon_factor * perimeter
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # 4. If the approximated shape has 4 points, it's a quadrilateral
        if len(approx) == 4:
            # 5. Ensure it is convex (no inward-bending sides)
            if cv2.isContourConvex(approx):
                squares.append(approx)
                
    return squares

def find_distorted_triangles(binary_image, min_area=1000, max_area=100000, epsilon_factor=0.04):
    """
    Finds distorted triangles (quadrilaterals) in a binarized image.
    
    Args:
        binary_image: A single-channel, 8-bit binarized image (numpy array).
        min_area: Minimum area of the contour to be considered (filters noise).
        epsilon_factor: Controls how loosely the contour is approximated. 
                        Higher = ignores more distortion.
                        
    Returns:
        A list of numpy arrays, where each array contains the 4 (x,y) coordinates 
        of a detected square's corners.
    """
    # 1. Find the contours of the objects
    # RETR_EXTERNAL gets only the outer edges, CHAIN_APPROX_SIMPLE compresses the data
    contours, _ = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    triangles = []
    
    for contour in contours:
        # 2. Ignore tiny specks of noise
        area=cv2.contourArea(contour)
        if (area < min_area or area > max_area):
            continue
            
        # 3. Approximate the contour to a polygon
        # arcLength calculates the perimeter. 
        perimeter = cv2.arcLength(contour, True)
        
        # Epsilon is the maximum distance from contour to approximated contour.
        # It is usually set to a percentage of the perimeter (e.g., 2% to 5%).
        epsilon = epsilon_factor * perimeter
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # 4. If the approximated shape has 4 points, it's a quadrilateral
        if len(approx) == 3:
            # 5. Ensure it is convex (no inward-bending sides)
            if cv2.isContourConvex(approx):
                triangles.append(approx)
                
    return triangles

def trunc(point, minx=0, miny=0, maxx=3999, maxy=2999):
    #point[0]=point[0]-500
    #point[1]=point[1]-500
    x=minx
    if(point[0]>minx and point[0]<maxx): x=point[0]
    elif(point[0]>minx): x=maxx
    y=miny
    if(point[1]>miny and point[1]<maxy): y=point[1]
    elif(point[1]>miny): y=maxy
    return [x,y]

def espandi_square(square, l=300):
    dir1=square[0,0]-square[2,0]
    #print(dir1)
    dir2=square[1,0]-square[3,0]
    n1=np.linalg.norm(dir1)
    n2=np.linalg.norm(dir2)
    dir1=dir1/n1
    dir2=dir2/n2
    sq=square.copy()
    sq[0,0]=trunc(square[0,0]+l*dir1)
    sq[2,0]=trunc(square[2,0]-l*dir1)
    sq[1,0]=trunc(square[1,0]+l*dir2)
    sq[3,0]=trunc(square[3,0]-l*dir2)
    return sq


def find_next_direction(element, dir):
    sq1=element[0]

    if (find_angle(sq1[0],sq1[1],[0,0],dir)<find_angle(sq1[1],sq1[2],[0,0],dir)):
        tdir=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
        tdir2=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
    else:
        tdir=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
        tdir2=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
    return tdir, tdir2

def find_next_direction2(element, dir, dir2):
    sq1=element[0]

    if (find_angle(sq1[0],sq1[1],[0,0],dir)<find_angle(sq1[1],sq1[2],[0,0],dir) and find_angle(sq1[0],sq1[1],[0,0],dir2)>find_angle(sq1[1],sq1[2],[0,0],dir2)):
        tdir=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
        tdir2=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
    elif(find_angle(sq1[0],sq1[1],[0,0],dir)>find_angle(sq1[1],sq1[2],[0,0],dir) and find_angle(sq1[0],sq1[1],[0,0],dir2)<find_angle(sq1[1],sq1[2],[0,0],dir2)):
        tdir=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
        tdir2=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
    else:
        print("Error in find_next_directio")
        return dir, dir2

    return tdir, tdir2

def create_intermidiate_element(el1,el2):
    p1=el1[1][0]
    p2=el2[1][0]
    #print(p1)
    p=np.array([[int((p1[0]+p2[0])/2),int((p1[1]+p2[1])/2)]])
    sq=np.array([[[0,0]],[[0,0]],[[0,0]],[[0,0]]])
    return [sq, p]

def create_final_element(el1,el2):
    p1=el1[1][0]
    p2=el2[1][0]
    #print(p1)
    p=np.array([[int((2*p1[0]-p2[0])),int((2*p1[1]-p2[1]))]])
    sq=np.array([[[0,0]],[[0,0]],[[0,0]],[[0,0]]])
    return [sq, p]

def obtain_points_and_square(squares):
    r=[]
    for square in squares:
        point=(square[0]+square[1]+square[2]+square[3])/4
        #print (point[0])
        #print (square)
        r.append([square,point])
    
    return r

def get_next_element_from_point(point, elements, dir):
    dmin=10000
    el=elements[0]
    index=0
    s=0
    for i in range(len(elements)):
        #_,d1,d2=find_closest_point_on_line(point,dir,points[i])
        e=elements[i]
        #print(e[1])
        #print(point)
        _,d1,_,d2=find_closest_point_on_line_angle2(point,dir,e[1])
        #if (d1<60 and d2<dmin and d2<600):#prev 60
        if (d1<0.25 and d2<dmin and d2<600):#prev 0.25
            dmin=d2
            index=i
            el=elements[i]
            s=1
    if(s==0):
        for i in range(len(elements)):
            e=elements[i]
            _,d1,d2=find_closest_point_on_line(point,dir,e[1])
            #print(e[1])
            #_,d1,d2=find_closest_point_on_line_angle(point,dir,e[1])
            if (d1<150 and d2<dmin and d2<600):#prev 60
            #if (d1<0.25 and d2<dmin and d2<600):#prev 60
                dmin=d2
                index=i
                el=elements[i]
                s=1
            if(s==0):
                print("errore in get_next_element_from_point: nessun punto trovato")
                return None,None
    return el,index

def get_next_element(element, elements, dir,lim=1500):
    dmin=10000
    el=elements[0]
    index=0
    s=0
    for i in range(len(elements)):
        e=elements[i]
        #_,d1,d2=find_closest_point_on_line(element[1],dir,e[1])
        #print(e[1])
        _,d1,d2=find_closest_point_on_line_angle(element[1],dir,e[1])
        #if (d1<60 and d2<dmin and d2<600):#prev 60
        if (d1<0.2 and d2<dmin and d2<600):#prev 60
            et=elements[i]
            sq1=element[0]
            sq2=et[0]
            j1=0
            j2=0
            j3=0
            j4=0
            for k in range(4):
                _,d,_=find_closest_point_on_line(sq1[0],dir,sq2[k])
                if(d<lim):
                    j1=j1+1
                _,d,_=find_closest_point_on_line(sq1[1],dir,sq2[k])
                if(d<lim):
                    j2=j2+1
                _,d,_=find_closest_point_on_line(sq1[2],dir,sq2[k])
                if(d<lim):
                    j3=j3+1
                _,d,_=find_closest_point_on_line(sq1[3],dir,sq2[k])
                if(d<lim):
                    j4=j4+1
            if(j1>=2 and j2>=2 and j3>=2 and j4>=2):
                dmin=d2
                index=i
                s=1
                el=et
    if(s==0):
        #print("errore in get_next_point: nessun punto trovato")
        return None,None
    return el,index

def get_next_element_d(element, elements, dir,lim=1500):
    dmin=10000
    el=elements[0]
    index=0
    s=0
    for i in range(len(elements)):
        e=elements[i]
        #_,d1,d2=find_closest_point_on_line(element[1],dir,e[1])
        #print(e[1])
        _,d1,_,d2=find_closest_point_on_line_angle2(element[1],dir,e[1])
        #if (d1<60 and d2<dmin and d2<600):#prev 60
        if (d1<0.2 and d2<dmin and d2<400):#prev 60
            et=elements[i]
            dmin=d2
            index=i
            s=1
            el=et
    if(s==0):
        for i in range(len(elements)):
            e=elements[i]
            #_,d1,d2=find_closest_point_on_line(element[1],dir,e[1])
            #print(e[1])
            _,d1,_,d2=find_closest_point_on_line_angle2(element[1],dir,e[1])
            #if (d1<60 and d2<dmin and d2<600):#prev 60
            if (d1<0.4 and d2<dmin and d2<400):#prev 60
                et=elements[i]
                dmin=d2
                index=i
                s=1
                el=et
        if(s==0):
            #print("errore in get_next_point: nessun punto trovato")
            return None,None,None
    return el,index, dmin


def get_next_element_dir_simp(element, elements, dir, dir2,lim=150):
    dmin=10000
    el=elements[0]
    index=0
    s=0
    for i in range(len(elements)):
        e=elements[i]
        #_,d1,d2=find_closest_point_on_line(element[1],dir,e[1])
        #print(e[1])
        _,d1,_,d2=find_closest_point_on_line_angle2(element[1],dir,e[1])
        #if (d1<80 and d2<dmin and d2<600):#prev 60
        if (d1<0.25 and d2<dmin and d2<400):#prev 0.25
                et=elements[i]
                angle=find_angle_sign([0,0],dir2[0],element[1][0],et[1][0])
                if(angle<np.pi/2):
                    el=et
                    dmin=d2
                    index=i
                    s=1                    
    if(s==0):
        for i in range(len(elements)):
            e=elements[i]
            #_,d1,d2=find_closest_point_on_line(element[1],dir,e[1])
            #print(e[1])
            _,d1,_,d2=find_closest_point_on_line_angle2(element[1],dir,e[1])
            if (d1<0.4 and d2<dmin and d2<400):#prev 60
            #if (d1<0.2 and d2<dmin and d2<600):#prev 60
                et=elements[i]
                angle=find_angle_sign([0,0],dir2[0],element[1][0],et[1][0])
                if(angle<np.pi/2):
                    el=et
                    dmin=d2
                    index=i
                    s=1   
        if(s==0):
            print("errore in get_next_point: nessun punto trovato")
            p=element[1]
            print(p)
            return None,None,None
    return el,index, dmin


def obtain_direction(triangle, elements):
    #print(triangle)
    leng=len(elements)
    trian_c=(triangle[0]+triangle[1]+triangle[2])/3
    min_d=10000
    index=0
    i=0
    while (i < leng):
        et=elements[i]
        d=ptop_distance(trian_c,et[1])
        if(d<min_d):
            min_d=d
            index=i
        i=i+1
    e=elements[index]
    square=e[0]
    #print(square)
    p=[]
    p.append(triangle[0,0])
    p.append(triangle[1,0])
    p.append(triangle[2,0])
    p.append(triangle[0,0])
    min_theta=3.14
    sel=0
    ind=0
    for i in range(3):
        theta=find_angle(p[i],p[i+1],square[0,0],square[1,0])
        if (theta<min_theta):
            min_theta=theta
            sel=0
            ind=i
        theta=find_angle(p[i],p[i+1],square[1,0],square[2,0])
        if (theta<min_theta):
            min_theta=theta
            sel=1
            ind=i

    dir11=square[0,0]-square[1,0]
    dir12=square[2,0]-square[3,0]
    if(np.dot(np.array(dir11),np.array(dir12))>0):
        dir1=dir11+dir12
    else:
        dir1=dir11-dir12
    dir1=dir1/2

    dir21=square[1,0]-square[2,0]
    dir22=square[3,0]-square[0,0]
    if(np.dot(np.array(dir21),np.array(dir22))>0):
        dir2=dir21+dir22
    else:
        dir2=dir21-dir22
    dir2=dir2/2

    if (sel==0):
        dir1=square[0,0]-square[1,0]
        dir2=square[1,0]-square[2,0]
    else:
        dir2=square[0,0]-square[1,0]
        dir1=square[1,0]-square[2,0]

    starting= (triangle[0,0]+triangle[1,0]+triangle[2,0])/3
    el,_=get_next_element_from_point(starting, elements, dir2)
    if (ind==0):
        p1=(triangle[0,0]+triangle[1,0])/2
        p2=triangle[2,0]
    elif(ind==1):
        p1=(triangle[1,0]+triangle[2,0])/2
        p2=triangle[0,0]
    else:
        p1=(triangle[0,0]+triangle[2,0])/2
        p2=triangle[1,0]   

    inv=0
    _,_,d1=find_closest_point_on_line(el[0],dir2,p1)
    _,_,d2=find_closest_point_on_line(el[0],dir2,p2)
    if(d2<d1): inv =1

    return dir1, dir2, inv


def raggruppa_elements_linea3(elements,st_el,dir,max_step):
    els=[]
    i=0
    et=st_el
    et1=et.copy()
    d_prev=0
    dirr=dir
    new_els=[]
    while(i<2):
        et, index, d_prev=get_next_element_d(et,elements,dirr)
        if (index==None):return els,i, new_els
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)

        if(not (square[0,0,0]==0 and square[0,0,1]==0 and square[1,0,0]==0 and square[1,0,1]==0)):
            
            t1=find_angle([0,0],dir,square[0,0],square[1,0])
            t2=find_angle([0,0],dir,square[1,0],square[2,0])
            #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
            #print (t1)
            #print (t2)
            if(t1>t2 ):
                dir1=square[1,0]-square[2,0]
                dir2=square[3,0]-square[0,0]
                if(np.dot(np.array(dir1),np.array(dir2))>0):
                    dirrt=dir1+dir2
                else:
                    dirrt=dir1-dir2
                dirrt=dirrt/2
                if(np.dot(np.array(dirr),np.array(dirrt))>0):
                    dirr=dirr+dirrt
                else:
                    dirr=dirr-dirrt
                dirr=dirr/2
            else:
            #elif(t3>t1):
                dir1=square[0,0]-square[1,0]
                dir2=square[2,0]-square[3,0]
                if(np.dot(np.array(dir1),np.array(dir2))>0):
                    dirrt=dir1+dir2
                else:
                    dirrt=dir1-dir2
                dirrt=dirrt/2
                if(np.dot(np.array(dirr),np.array(dirrt))>0):
                    dirr=dirr+dirrt
                else:
                    dirr=dirr-dirrt
                dirr=dirr/2
                #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
                #dirr=dirr/2
            #else:
            #    dirr=square[0,0]-square[2,0]
        i=i+1
    
    while (i<max_step):
        e1=els[i-2]
        e2=els[i-1]
        dir2=e2[1]-e1[1]
        et1, index,d=get_next_element_dir_simp(et,elements,dirr,dir2)
        if (index==None):
            if(i==(max_step-1)):
                et=create_final_element(e2,e1)
                els.append(et)
                new_els.append(et)
                return els, i+1, new_els
            else: return els,i, new_els
        if (d>1.75*d_prev and not(i==(max_step-1))):#crea un punto intermedio quando la distanza tra 2 punti è troppo grande ( il quadrato associato è [[0,0],[0,0],[0,0],[0,0]])
            elt=create_intermidiate_element(et1,et)
            els.append(elt)
            new_els.append(elt)
            d_prev=d/2
            i=i+1
        else:
            d_prev=d
        et=et1
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)

        
        t1=find_angle([0,0],dir,square[0,0],square[1,0])
        t2=find_angle([0,0],dir,square[1,0],square[2,0])
        #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
        #print (t1)
        #print (t2)
        if(t1>t2 ):
            dir1=square[1,0]-square[2,0]
            dir2=square[3,0]-square[0,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
        else:
        #elif(t3>t1):
            dir1=square[0,0]-square[1,0]
            dir2=square[2,0]-square[3,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
            #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
            #dirr=dirr/2
        #else:
        #    dirr=square[0,0]-square[2,0]
        #print (i)
        #print(dirr)
        i=i+1

    #print("errore")
    return els,i, new_els


def raggruppa_elements_linea_bordo(elements,st_el,dir,max_step, exp_d):
    els=[]
    i=0
    et=st_el
    et1=et.copy()
    d_prev=exp_d
    dirr=dir
    d=0
    while(i<2):
        et, index, d=get_next_element_d(et,elements,dirr)
        if (index==None):return els,i
        '''
        if (d>1.75*d_prev):#crea un punto intermedio quando la distanza tra 2 punti è troppo grande ( il quadrato associato è [[0,0],[0,0],[0,0],[0,0]])
            elt=create_intermidiate_element(et1,et)
            els.append(elt)
            d_prev=d/2
            i=i+1
        elif(d>0.25*d_prev):
            d_prev=d
        '''
        d_prev=d
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)


        t1=find_angle([0,0],dir,square[0,0],square[1,0])
        t2=find_angle([0,0],dir,square[1,0],square[2,0])
        #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
        #print (t1)
        #print (t2)
        if(t1>t2 ):
            dir1=square[1,0]-square[2,0]
            dir2=square[3,0]-square[0,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
        else:
        #elif(t3>t1):
            dir1=square[0,0]-square[1,0]
            dir2=square[2,0]-square[3,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
            #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
            #dirr=dirr/2
        #else:
        #    dirr=square[0,0]-square[2,0]
        i=i+1
    
    while (i<max_step):
        e1=els[i-2]
        e2=els[i-1]
        dir2=e2[1]-e1[1]
        et1, index,d=get_next_element_dir_simp(et,elements,dirr,dir2)
        if (index==None):return els,i
        if (d>1.75*d_prev):#crea un punto intermedio quando la distanza tra 2 punti è troppo grande ( il quadrato associato è [[0,0],[0,0],[0,0],[0,0]])
            elt=create_intermidiate_element(et1,et)
            els.append(elt)
            d_prev=d/2
            i=i+1
        else:
            d_prev=d
        et=et1
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)

        
        t1=find_angle([0,0],dir,square[0,0],square[1,0])
        t2=find_angle([0,0],dir,square[1,0],square[2,0])
        #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
        #print (t1)
        #print (t2)
        if(t1>t2 ):
            dir1=square[1,0]-square[2,0]
            dir2=square[3,0]-square[0,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
        else:
        #elif(t3>t1):
            dir1=square[0,0]-square[1,0]
            dir2=square[2,0]-square[3,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
            #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
            #dirr=dirr/2
        #else:
        #    dirr=square[0,0]-square[2,0]
        #print (i)
        #print(dirr)
        i=i+1

    #print("errore")
    return els,i

def raggruppa_elements_linea_bordo2(elements,st_el,dir,max_step):
    els=[]
    new_els=[]
    i=0
    et=st_el
    et1=et.copy()
    d_prev=0
    dirr=dir
    while(i<2):
        et, index, d_prev=get_next_element_d(et,elements,dirr)
        if (index==None):return els,i,dirr,new_els
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)


        t1=find_angle([0,0],dir,square[0,0],square[1,0])
        t2=find_angle([0,0],dir,square[1,0],square[2,0])
        #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
        #print (t1)
        #print (t2)
        if(t1>t2 ):
            dir1=square[1,0]-square[2,0]
            dir2=square[3,0]-square[0,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
        else:
        #elif(t3>t1):
            dir1=square[0,0]-square[1,0]
            dir2=square[2,0]-square[3,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
            #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
            #dirr=dirr/2
        #else:
        #    dirr=square[0,0]-square[2,0]
        i=i+1
    
    while (i<max_step):
        e1=els[i-2]
        e2=els[i-1]
        dir2=e2[1]-e1[1]
        et1, index,d=get_next_element_dir_simp(et,elements,dirr,dir2)
        if (index==None):return els,i,dirr,new_els
        if (d>1.75*d_prev):#crea un punto intermedio quando la distanza tra 2 punti è troppo grande ( il quadrato associato è [[0,0],[0,0],[0,0],[0,0]])
            elt=create_intermidiate_element(et1,et)
            els.append(elt)
            new_els.append(elt)
            d_prev=d/2
            i=i+1
        else:
            d_prev=d
        et=et1
        els.append(et)
        e=elements[index]
        square=e[0]
        elements.pop(index)

        
        t1=find_angle([0,0],dir,square[0,0],square[1,0])
        t2=find_angle([0,0],dir,square[1,0],square[2,0])
        #t3=find_angle([0,0],dirr,square[0,0],square[2,0])
        #print (t1)
        #print (t2)
        if(t1>t2 ):
            dir1=square[1,0]-square[2,0]
            dir2=square[3,0]-square[0,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
        else:
        #elif(t3>t1):
            dir1=square[0,0]-square[1,0]
            dir2=square[2,0]-square[3,0]
            if(np.dot(np.array(dir1),np.array(dir2))>0):
                dirrt=dir1+dir2
            else:
                dirrt=dir1-dir2
            dirrt=dirrt/2
            if(np.dot(np.array(dirr),np.array(dirrt))>0):
                dirr=dirr+dirrt
            else:
                dirr=dirr-dirrt
            dirr=dirr/2
            #dirr=square[0,0]-square[1,0]+square[2,0]-square[3,0]
            #dirr=dirr/2
        #else:
        #    dirr=square[0,0]-square[2,0]
        #print (i)
        #print(dirr)
        i=i+1

    #print("errore")
    return els,i,dirr,new_els

def find_elements_rows(elements, starting, dir1, dir2,max_step):
    #si possono aggiungere più controlli
    arrs=[]
    el,_=get_next_element_from_point(starting,elements,dir1)

    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step-1)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting,elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element(el,elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element(el,elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    
    return arrs

def find_elements_rows3(elements, starting, dir1, dir2,max_step):
    #si possono aggiungere più controlli
    arrs=[]
    el,_=get_next_element_from_point(starting,elements,dir1)

    ps,_,dirr,new_els1=raggruppa_elements_linea_bordo2(elements, el, dir1,max_step-1)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting,elements,dir2)
    ps,_,new_els2=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element(el,elements,dir2)
    ps,_,new_els3=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element(el,elements,dir2)
    ps,_,new_els4=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    new_els=[]
    for el in new_els1:
        new_els.append(el)
    for el in new_els2:
        new_els.append(el)
    for el in new_els3:
        new_els.append(el)
    for el in new_els4:
        new_els.append(el)
    
    return arrs, dirr, new_els

def find_elements_rows2(elements, starting_el, dir1, dir2,max_step):
    #si possono aggiungere più controlli
    #'''
    arrs=[]
    el, _=get_next_element_from_point(starting_el[0][1],elements,dir2)

    exp_d=ptop_distance(starting_el[0][1],starting_el[1][1])
    ps,_=raggruppa_elements_linea_bordo(elements, el, dir1,max_step-1,exp_d)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[1][1],elements,dir2)
    ps,_,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[2][1],elements,dir2)
    ps,_,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[3][1],elements,dir2)
    ps,_,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    '''
    arrs=[]

    
    el, _=get_next_element_from_point(starting_el[3][1],elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[2][1],elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[1][1],elements,dir2)
    ps,_=raggruppa_elements_linea3(elements, el, dir1,max_step)
    arrs.append(ps)
    el, _=get_next_element_from_point(starting_el[0][1],elements,dir2)

    exp_d=ptop_distance(starting_el[0][1],starting_el[1][1])
    ps,_=raggruppa_elements_linea_bordo(elements, el, dir1,max_step-1,exp_d)
    arrs.append(ps)
    #'''
    return arrs

def elimina_quadrati_dove_triangoli(squares, triangles):
    trian_cs=[]
    tri_l=len(triangles)
    sq=squares.copy()
    for i in range(tri_l):
        triangle=triangles[i]
        trian_c=(triangle[0]+triangle[1]+triangle[2])/3
        trian_cs.append(trian_c)
    j=0
    for i in range(len(squares)):
        for el in trian_cs:
            if(ptop_distance(el,squares[i][1])<50):
                sq.pop(i-j)
                j=j+1
                break
    return sq
                


def obtain_square(img, kernel_d=15):

    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    imgc=img.copy()

    rett, thresh = cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    kernel=np.ones((10,10),np.uint8)
    img2=cv2.erode(thresh,kernel)
    #triangles=find_distorted_triangles(img2,min_area=100,max_area=10000)#other values possible to change

    binary_edges=find_edges(gray, treshold=20)
    binary_edges=cv2.medianBlur(binary_edges,5)
    '''
    plt.imshow(binary_edges)
    plt.show()
    #'''

    big_sq, trovato=find_biggest_squares(binary_edges)
    if (trovato==0):
        print("non trovato")
        bi2=find_edges(gray, treshold=10)
        bi2=cv2.medianBlur(binary_edges,5)
        big_sq, trovato=find_biggest_squares(bi2)
        if(trovato==0):
            ("NON torvato")
        else:
            big_sq=espandi_square(big_sq[0])
            binary_edges=mask_outside_polygon(binary_edges,big_sq)
            img2=mask_outside_polygon(img2,big_sq)
            cv2.drawContours(imgc, [big_sq], -1, (0,0, 255), 3)
    else:
        big_sq=espandi_square(big_sq[0])
        binary_edges=mask_outside_polygon(binary_edges,big_sq)
        img2=mask_outside_polygon(img2,big_sq)
        cv2.drawContours(imgc, [big_sq], -1, (0,0, 255), 3)

    #triangles=find_distorted_triangles(thresh,min_area=100,max_area=10000)
    triangles=find_distorted_triangles(img2,min_area=1000,max_area=10000)
    '''
    plt.imshow(binary_edges)
    plt.show()
    #'''
    prova=cv2.medianBlur(binary_edges,5)
    #kernel = np.ones((15,15),np.uint8)
    kernel = np.ones((kernel_d,kernel_d),np.uint8)#possible to change
    prova=cv2.dilate(prova, kernel)
    squares=find_distorted_squares(prova)
    '''
    cv2.drawContours(imgc, squares, -1, (0, 255, 0), 3)    
    cv2.drawContours(imgc, triangles, -1, (0, 255, 0), 3)    
    plt.imshow(imgc)
    plt.show()
    #'''
    elements=obtain_points_and_square(squares)
    elements=elimina_quadrati_dove_triangoli(elements,triangles)
    elements2=elements.copy()
    elements3=elements.copy()
    elements4=elements.copy()
    if (len(triangles)>2):
        print("Error: too many triangles")
        return 0,None, None
    elif(len(triangles)==2):
        a1=cv2.contourArea(triangles[0])
        a2=cv2.contourArea(triangles[1])
        if(a1>a2):
            triangle=triangles[0]
        else:
            triangle=triangles[1]
    else:
        triangle=triangles[0]
    #print(triangle)
    starting=(triangle[0]+triangle[1]+triangle[2])/3
    #print(starting)
    dir,dir2,inv=obtain_direction(triangle,elements)
    '''
    points=find_elements_rows(elements,starting,dir2,dir,20)
    points2=find_elements_rows(elements2,starting,dir,dir2,16)
    st1=points2[0][14]
    st2=points2[0][13]
    st3=points2[0][12]
    st4=points2[0][11]
    sq1=points2[0][14][0]
    print(sq1)

    if (find_angle(sq1[0],sq1[1],[0,0],dir2)<find_angle(sq1[1],sq1[2],[0,0],dir2)):
        tdir=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
        tdir2=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
    else:
        tdir=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
        tdir2=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
    points3=find_elements_rows2(elements3,[st1,st2,st3,st4],tdir,tdir2,20)
    '''
    points, ndir1, new_els1=find_elements_rows3(elements,starting,dir2,dir,20)
    points2, ndir2, new_els2=find_elements_rows3(elements2,starting,dir,dir2,16)
    st1=points2[0][14]
    st2=points2[0][13]
    st3=points2[0][12]
    st4=points2[0][11]
    sq1=points2[0][14][0]
    #print(sq1)

    if (find_angle(sq1[0],sq1[1],[0,0],ndir2)<find_angle(sq1[1],sq1[2],[0,0],ndir2)):
        tdir2=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
        tdir=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
    else:
        tdir2=[sq1[1][0][0]-sq1[2][0][0],sq1[1][0][1]-sq1[2][0][1]]
        tdir=[sq1[0][0][0]-sq1[1][0][0],sq1[0][0][1]-sq1[1][0][1]]
    for el in new_els2:
        elements3.append(el)
    points3=find_elements_rows2(elements3,[st1,st2,st3,st4],tdir,tdir2,20)
    '''
    print(len(points[0]))
    for element in points:
        for point in element:
            p=point[1][0]
            x=int(p[0])
            y=int(p[1])
            cv2.circle(img,(x,y),10,(255,0,0),10)
    plt.imshow(img)
    plt.show()
    '''
    '''
    st1=points[0][18]
    st2=points[0][17]
    st3=points[0][16]
    st4=points[0][15]
    sq2=points[0][18][0]
    print(sq2)
    if (find_angle(sq2[0],sq2[1],[0,0],dir2)<find_angle(sq2[1],sq2[2],[0,0],dir2)):
        tdir=[sq2[0][0][0]-sq2[1][0][0],sq2[0][0][1]-sq2[1][0][1]]
        tdir2=[sq2[1][0][0]-sq2[2][0][0],sq2[1][0][1]-sq2[2][0][1]]
    else:
        tdir=[sq2[1][0][0]-sq2[2][0][0],sq2[1][0][1]-sq2[2][0][1]]
        tdir2=[sq2[0][0][0]-sq2[1][0][0],sq2[0][0][1]-sq2[1][0][1]]
    points4=find_elements_rows2(elements4,[st1,st2,st3,st4],tdir2,tdir,16)
    '''
    st1=points[0][18]
    st2=points[0][17]
    st3=points[0][16]
    st4=points[0][15]
    sq2=points[0][18][0]
    #print(sq2)
    if (find_angle(sq2[0],sq2[1],[0,0],ndir1)<find_angle(sq2[1],sq2[2],[0,0],ndir1)):
        tdir=[sq2[0][0][0]-sq2[1][0][0],sq2[0][0][1]-sq2[1][0][1]]
        tdir2=[sq2[1][0][0]-sq2[2][0][0],sq2[1][0][1]-sq2[2][0][1]]
    else:
        tdir=[sq2[1][0][0]-sq2[2][0][0],sq2[1][0][1]-sq2[2][0][1]]
        tdir2=[sq2[0][0][0]-sq2[1][0][0],sq2[0][0][1]-sq2[1][0][1]]
    for el in new_els1:
        elements4.append(el)
    points4=find_elements_rows2(elements4,[st1,st2,st3,st4],tdir2,tdir,16)
    
    img_points=[]
    '''
    for element in points:
        for point in element:
            #img_points.append([int(point[0,0]),int(point[0,1])])
            #print (point)
            t=point[1]
            img_points.append(t[0])
    #'''
    '''
    for element in points2:
        for point in element:
            #img_points.append([int(point[0,0]),int(point[0,1])])
            t=point[1]
            img_points.append(t[0])
    #'''
    '''
    for element in points3:
        for point in element:
            #img_points.append([int(point[0,0]),int(point[0,1])])
            t=point[1]
            img_points.append(t[0])
    #'''
    '''
    for element in points4:
        for point in element:
            #img_points.append([int(point[0,0]),int(point[0,1])])
            t=point[1]
            img_points.append(t[0])
    #'''
    #'''
    for point in points3[3]:
        t=point[1]
        img_points.append(t[0])
    #'''

    img_points=np.array(img_points)
    #'''
    for point in img_points:
        x=int(point[0])
        y=int(point[1])
        cv2.circle(imgc,(x,y),10,(255,0,0),10)
    
    '''
    for point in points2[3]:
        point=point[1]
        x=int(point[0,0])
        y=int(point[0,1])
        cv2.circle(img,(x,y),10,(255,0,0),10)
    '''
    '''
    cv2.drawContours(imgc, squares, -1, (0, 255, 0), 3)    
    cv2.drawContours(imgc, triangles, -1, (0, 255, 0), 3)
    plt.imshow(imgc)
    plt.show()
    #'''
    #'''
    return([points, points2, points3, points4],inv)

def find_corners(img):
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    gray = np.float32(gray)

    dst = cv2.cornerHarris(gray,11,21,0.0004)
    dst = cv2.dilate(dst,None)
    ret, dst = cv2.threshold(dst,0.01*dst.max(),255,0)
    dst = np.uint8(dst)
    ret, labels, stats, centroids = cv2.connectedComponentsWithStats(dst, connectivity=8)
 
    # define the criteria to stop and refine the corners
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.001)
    corners = cv2.cornerSubPix(gray,np.float32(centroids),(5,5),(-1,-1),criteria)

    # Now draw them
    res = np.hstack((centroids,corners))
    '''
    img2=img.copy()
    #res = np.uint8(res)
    #img[res[:,1],res[:,0]]=[0,0,255]
    #img[res[:,3],res[:,2]] = [0,255,0]
    for point in res:
        x=int(point[2])
        y=int(point[3])
        cv2.circle(img2,(x,y),10,(255,0,0),10)

    plt.imshow(img2)
    plt.show()
    #'''
    return res
'''
def re_arreange_corners_sq(square, dir1, dir2):
    #funzione da testare
    center=(square[0]+square[1]+square[2]+square[3])/4
    n1=np.linalg.norm(dir1[0])
    n2=np.linalg.norm(dir2[0])
    dir1=dir1[0]/n1
    dir2=dir2[0]/n2
    
    m=[[dir1[0],dir2[0]],[dir1[1],dir2[1]]]
    #print(m)
    m=np.matrix(m)
    m=np.transpose(m)
    new_sq=square-[center,center,center,center]
    r=[[[0,0]],[[0,0]],[[0,0]],[[0,0]]]
    for i in range(4):
        #print(new_sq[i,0])
        el=np.dot(new_sq[i,0],m)
        print(el)
        if(el[0,0]>0 and el[0,1]>0):
            r[0]=square[i]
        elif(el[0,0]>0 and el[0,1]<0):
            r[1]=square[i]
        elif(el[0,0]<0 and el[0,1]<0):
            r[2]=square[i]
        else:
            r[3]=square[i]
    print(r)
    return np.array(r)
'''
def re_arreange_corners_sq(square, dir1, dir2):
    #funzione da testare
    center=(square[0]+square[1]+square[2]+square[3])/4
    n1=np.linalg.norm(dir1[0])
    n2=np.linalg.norm(dir2[0])
    dir1=dir1[0]/n1
    dir2=dir2[0]/n2
    
    m=[[dir1[0],dir2[0]],[dir1[1],dir2[1]]]
    #print(m)
    m=np.matrix(m)
    m=np.transpose(m)
    new_sq=square-[center,center,center,center]
    r=[[[0,0]],[[0,0]],[[0,0]],[[0,0]]]
    els=[]
    thetas=[]
    for i in range(4):
        el=np.dot(new_sq[i,0],m)
        th=(np.atan(el[0,0]/el[0,1]))
        #th=(np.atan(el[0,1]/el[0,0]))
        #print(el[0,0])
        #print(el[0,1])
        if(el[0,1]<0):
            th=th+np.pi
        #print(th)
        thetas.append(th)
    sorted_th=np.sort(np.array(thetas))
    for k in range(4):
        for i in range(4):
            if (thetas[k]==sorted_th[i]):
                if (i==0):
                    r[3]=square[k]
                else:
                    r[i-1]=square[k]

    #print(r)
    return np.array(r)

def find_close_corners(sq1,sq2,max=60):
    max2=120
    for i in range(4):
        for j in range(4):
            if (ptop_distance(sq1[i],sq2[j])<max):
                return average_of_points([sq1[i],sq2[j]])
    
    print("allargato massima distanza in find close corners")
    for i2 in range(4):
        for j2 in range(4):
            if (ptop_distance(sq1[i2],sq2[j2])<max2):
                return average_of_points([sq1[i2],sq2[j2]])
            
    print("nessun punto trovato in find close corners")
    print(sq1)
    print(sq2)
    return None

def aggiorna(corners,p,radious,r,real_points,point):
    l=len(corners)
    i=0
    points=[]
    while(i<l):
        if(ptop_distance(p,corners[i])<radious):
            points.append(corners[i])
            corners.pop(i)
            l=l-1
        else: i=i+1
    if(not points==[]):
        rt=average_of_points(points)
        r.append(rt)
        real_points.append(point)
    else:
        ra2=radious*1.5
        l=len(corners)
        i=0
        points=[]
        while(i<l):
            if(ptop_distance(p,corners[i])<ra2):
                points.append(corners[i])
                corners.pop(i)
                l=l-1
            else: i=i+1
        if(not points==[]):
            rt=average_of_points(points)
            r.append(rt)
            real_points.append(point)
        else:
            ra2=radious*2
            l=len(corners)
            i=0
            points=[]
            while(i<l):
                if(ptop_distance(p,corners[i])<ra2):
                    points.append(corners[i])
                    corners.pop(i)
                    l=l-1
                else: i=i+1
            if(not points==[]):
                rt=average_of_points(points)
                r.append(rt)
                real_points.append(point)      
    return 0

def find_corner_correspondence1_3(els, corners, n, starting, v1, v2):
    #starting, v1 and v2 has to be np array
    radious=30
    r=[]
    real_points=[]
    suppose_points=[]
    p=find_close_corners(els[0][0][0],els[1][0][0])[0]
    suppose_points.append(p)
    aggiorna(corners,p,radious,r,real_points,starting)

    current=starting
    for j in range(n-1):
        p2=[]
        if (not els[0][j][0][0,0,0]==0 and not els[1][j+2][0][0,0,0]==0):
                pt=find_close_corners(els[0][j][0],els[1][j+2][0])[0]
                p2.append(pt)
                
        if (not els[0][j+1][0][0,0,0]==0 and not els[1][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[0][j+1][0],els[1][j+1][0])[0]
                p2.append(pt)
                #suppose_points.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    current=starting+v2
    for j in range(n):
        p2=[]
        if (not els[1][j][0][0,0,0]==0 and not els[2][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[1][j][0],els[2][j+1][0])[0]
                p2.append(pt)
        if (not els[1][j+1][0][0,0,0]==0 and not els[2][j][0][0,0,0]==0):
                pt=find_close_corners(els[1][j+1][0],els[2][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    current=current+v2
    for j in range(n):
        p2=[]
        if (not els[2][j][0][0,0,0]==0 and not els[3][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[2][j][0],els[3][j+1][0])[0]
                p2.append(pt)
        if (not els[2][j+1][0][0,0,0]==0 and not els[3][j][0][0,0,0]==0):
                pt=find_close_corners(els[2][j+1][0],els[3][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    return np.array(r), np.array(real_points), np.array(suppose_points)
    # Da rivedere 
    #Per caso base funziona

def find_corner_correspondence2_3(els, corners, n, starting, v1, v2):
    #starting, v1 and v2 has to be np array
    radious=30
    r=[]
    real_points=[]
    suppose_points=[]
    current=starting
    for j in range(3,n-1):

        p2=[]
        if (not els[0][j][0][0,0,0]==0 and not els[1][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[0][j][0],els[1][j+1][0])[0]
                p2.append(pt)
        if (not els[0][j+1][0][0,0,0]==0 and not els[1][j][0][0,0,0]==0):
                pt=find_close_corners(els[0][j+1][0],els[1][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua

    
    p=find_close_corners(els[0][n-1][0],els[1][n][0])[0]
    suppose_points.append(p)
    point=starting+v1*n
    aggiorna(corners,p,radious,r,real_points,point)

    current=starting+v2
    for j in range(3,n):
        p2=[]
        if (not els[1][j][0][0,0,0]==0 and not els[2][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[1][j][0],els[2][j+1][0])[0]
                p2.append(pt)
        if (not els[1][j+1][0][0,0,0]==0 and not els[2][j][0][0,0,0]==0):
                pt=find_close_corners(els[1][j+1][0],els[2][j][0])[0]
                p2.append(pt)
                #suppose_points.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    current=current+v2
    for j in range(3,n):
        #d1=ptop_distance(els[2][j][0][0],els[2][j][0][1])
        #d2=ptop_distance(els[2][j][0][2],els[2][j][0][1])
        #radious=(d1+d2)/8
        p2=[]
        if (not els[2][j][0][0,0,0]==0 and not els[3][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[2][j][0],els[3][j+1][0])[0]
                p2.append(pt)
        if (not els[2][j+1][0][0,0,0]==0 and not els[3][j][0][0,0,0]==0):
                pt=find_close_corners(els[2][j+1][0],els[3][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    return np.array(r), np.array(real_points), np.array(suppose_points)
    # Da rivedere 
    #Per caso base funziona  

def find_corner_correspondence3_3(els, corners, n, starting, v1, v2):
    #starting, v1 and v2 has to be np array
    radious=30
    r=[]
    real_points=[]
    suppose_points=[]
    current=starting
    for j in range(3,n):

        p2=[]
        if (not els[0][j][0][0,0,0]==0 and not els[1][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[0][j][0],els[1][j+1][0])[0]
                p2.append(pt)
        if (not els[0][j+1][0][0,0,0]==0 and not els[1][j][0][0,0,0]==0):
                pt=find_close_corners(els[0][j+1][0],els[1][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua

    current=starting+v2
    for j in range(3,n):
        p2=[]
        if (not els[1][j][0][0,0,0]==0 and not els[2][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[1][j][0],els[2][j+1][0])[0]
                p2.append(pt)
        if (not els[1][j+1][0][0,0,0]==0 and not els[2][j][0][0,0,0]==0):
                pt=find_close_corners(els[1][j+1][0],els[2][j][0])[0]
                p2.append(pt)
                #suppose_points.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    current=current+v2
    for j in range(3,n):
        #d1=ptop_distance(els[2][j][0][0],els[2][j][0][1])
        #d2=ptop_distance(els[2][j][0][2],els[2][j][0][1])
        #radious=(d1+d2)/8
        p2=[]
        if (not els[2][j][0][0,0,0]==0 and not els[3][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[2][j][0],els[3][j+1][0])[0]
                p2.append(pt)
        if (not els[2][j+1][0][0,0,0]==0 and not els[3][j][0][0,0,0]==0):
                pt=find_close_corners(els[2][j+1][0],els[3][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    return np.array(r), np.array(real_points), np.array(suppose_points)
    # Da rivedere 
    #Per caso base funziona        


def find_corner_correspondence4_3(els, corners, n, starting, v1, v2):
    #starting, v1 and v2 has to be np array
    radious=30
    r=[]
    real_points=[]
    suppose_points=[]
    current=starting
    for j in range(3,n):

        p2=[]
        if (not els[0][j-1][0][0,0,0]==0 and not els[1][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[0][j-1][0],els[1][j+1][0])[0]
                p2.append(pt)
        if (not els[0][j][0][0,0,0]==0 and not els[1][j][0][0,0,0]==0):
                pt=find_close_corners(els[0][j][0],els[1][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua

    current=starting+v2
    for j in range(3,n):
        p2=[]
        if (not els[1][j][0][0,0,0]==0 and not els[2][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[1][j][0],els[2][j+1][0])[0]
                p2.append(pt)
        if (not els[1][j+1][0][0,0,0]==0 and not els[2][j][0][0,0,0]==0):
                pt=find_close_corners(els[1][j+1][0],els[2][j][0])[0]
                p2.append(pt)
                #suppose_points.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    current=current+v2
    for j in range(3,n):
        #d1=ptop_distance(els[2][j][0][0],els[2][j][0][1])
        #d2=ptop_distance(els[2][j][0][2],els[2][j][0][1])
        #radious=(d1+d2)/8
        p2=[]
        if (not els[2][j][0][0,0,0]==0 and not els[3][j+1][0][0,0,0]==0):
                pt=find_close_corners(els[2][j][0],els[3][j+1][0])[0]
                p2.append(pt)
        if (not els[2][j+1][0][0,0,0]==0 and not els[3][j][0][0,0,0]==0):
                pt=find_close_corners(els[2][j+1][0],els[3][j][0])[0]
                p2.append(pt)
        if(not p2==[]):
            p=average_of_points(p2)
            suppose_points.append(p)
            point=current+v1*j
            aggiorna(corners,p,radious,r,real_points,point)
        else:
            p=0
            #devo ancore decidere cosa inserire qua
    return np.array(r), np.array(real_points), np.array(suppose_points)
    # Da rivedere 
    #Per caso base funziona        

    
def get_points(img):
    '''
    This function return the position of the corners of the chessboard on the camera and in the real world  
    The how is a bit long to explain 
    '''
    img_copy=img.copy()
    try:
        square, inv=obtain_square(img)
    except:
        try:
            square, inv=obtain_square(img,25)
        except:
            print("get_points fallito")
            return None,None,None
    corners=find_corners(img)
    corners2=[]
    for el in corners:
        c=[el[0],el[1]]
        corners2.append(c)
    #'''
    z=0.0
    #corners2=np.array(corners2)
    if (inv==0):
        starting=np.array([9000.0,7000.0,z])
        v1=np.array([-1000,0,z])
        v2=np.array([0,-1000,z])
        res1, real1, sup1=find_corner_correspondence1_3(square[0],corners2,19,starting,v1,v2)
        v2=np.array([-1000,0,z])
        v1=np.array([0,-1000,z])
        res2, real2, sup2=find_corner_correspondence4_3(square[1],corners2,15,starting,v1,v2)
        starting=np.array([9000.0,-7000.0,z])
        v1=np.array([-1000,0,z])
        v2=np.array([0,1000,z])
        res3,real3, sup3=find_corner_correspondence2_3(square[2],corners2,19,starting,v1,v2)
        starting=np.array([-9000.0,7000.0,z])
        v2=np.array([1000,0,z])
        v1=np.array([0,-1000,z])
        res4,real4, sup4=find_corner_correspondence3_3(square[3],corners2,12,starting,v1,v2)
    else:
        starting=np.array([-9000.0,-7000.0,z])
        v1=np.array([1000,0,z])
        v2=np.array([0,1000,z])
        res1, real1, sup1=find_corner_correspondence1_3(square[0],corners2,19,starting,v1,v2)
        v2=np.array([1000,0,z])
        v1=np.array([0,1000,z])
        res2, real2, sup2=find_corner_correspondence4_3(square[1],corners2,15,starting,v1,v2)
        starting=np.array([-9000.0,7000.0,z])
        v1=np.array([1000,0,z])
        v2=np.array([0,-1000,z])
        res3,real3, sup3=find_corner_correspondence2_3(square[2],corners2,19,starting,v1,v2)
        starting=np.array([9000.0,-7000.0,z])
        v2=np.array([-1000,0,z])
        v1=np.array([0,1000,z])
        res4,real4, sup4=find_corner_correspondence3_3(square[3],corners2,12,starting,v1,v2)
    #'''
    '''
    if (inv==0):
        starting=np.array([9000.0,7000.0])
        v1=np.array([-1000,0])
        v2=np.array([0,-1000])
        res1, real1, sup1=find_corner_correspondence1_3(square[0],corners2,19,starting,v1,v2)
        v2=np.array([-1000,0])
        v1=np.array([0,-1000])
        res2, real2, sup2=find_corner_correspondence4_3(square[1],corners2,15,starting,v1,v2)
        starting=np.array([9000.0,-7000.0])
        v1=np.array([-1000,0])
        v2=np.array([0,1000])
        res3,real3, sup3=find_corner_correspondence2_3(square[2],corners2,19,starting,v1,v2)
        starting=np.array([-9000.0,7000.0])
        v2=np.array([1000,0])
        v1=np.array([0,-1000])
        res4,real4, sup4=find_corner_correspondence3_3(square[3],corners2,12,starting,v1,v2)
    else:
        starting=np.array([-9000.0,-7000.0])
        v1=np.array([1000,0])
        v2=np.array([0,1000])
        res1, real1, sup1=find_corner_correspondence1_3(square[0],corners2,19,starting,v1,v2)
        v2=np.array([1000,0])
        v1=np.array([0,1000])
        res2, real2, sup2=find_corner_correspondence4_3(square[1],corners2,15,starting,v1,v2)
        starting=np.array([-9000.0,7000.0])
        v1=np.array([1000,0])
        v2=np.array([0,-1000])
        res3,real3, sup3=find_corner_correspondence2_3(square[2],corners2,19,starting,v1,v2)
        starting=np.array([9000.0,-7000.0])
        v2=np.array([-1000,0])
        v1=np.array([0,1000])
        res4,real4, sup4=find_corner_correspondence3_3(square[3],corners2,12,starting,v1,v2)
    #'''
            
    res=[]
    real=[]
    sup=[]

    for i in range(len(res1)):
        res.append(res1[i])
        real.append(real1[i])
    for i in range(len(res2)):
        res.append(res2[i])
        real.append(real2[i])
    for i in range(len(res3)):
        res.append(res3[i])
        real.append(real3[i])
    for i in range(len(res4)):
        res.append(res4[i])
        real.append(real4[i])
    '''
    for i in range(len(sup1)):
        sup.append(sup1[i])
    for i in range(len(sup2)):
        sup.append(sup2[i])
    for i in range(len(sup3)):
        sup.append(sup3[i])
    for i in range(len(sup4)):
        sup.append(sup4[i])
    #'''
    print (len(real))
    
    '''
    for point in res:
        x=int(point[0])
        y=int(point[1])
        cv2.circle(img_copy,(x,y),10,(255,0,0),10)
    plt.imshow(img_copy)
    plt.show()
    #'''
    res=np.array(res)
    real=np.array(real)
    res=np.float32(res)
    real=np.float32(real)
    return res, real,1


'''
img_name="img3/5.jpg"

img=cv2.imread(img_name)
get_points(img)
#'''