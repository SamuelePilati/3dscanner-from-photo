import cv2
import numpy as np
from matplotlib import pyplot as plt
import json

from funzioni import line_plane_intersection

def mask_outside_polygon(img, approx):
    '''
    This function returns the image with every part outside the poligon(approx input) black
    
    '''
    mask = np.zeros(img.shape[:2], dtype=np.uint8)

    cv2.drawContours(mask, [approx], -1, 255, -1)

    result = cv2.bitwise_and(img, img, mask=mask)

    return result

def obtain_shadow(rotation_matrix, translation_vector, contour, plane_height, camera_matrix, dist_coefs):
    '''
    Function to find the projection of an object on a given orrizontal plane (plane height)
    '''
    
    black2=np.zeros((3000,4000,1),dtype=np.uint8)
    white=255-black2
    new_contours=[]
    plane_normal=[0,0,1]
    plane_point=[0,0,plane_height]
    d=camera_matrix[0][0]
    t2=[translation_vector[0][0],translation_vector[1][0],translation_vector[2][0]]
    '''
    d=camera_matrix[0][0]
    t2=np.array(t2)
    n2=np.linalg.norm(t2)
    d2=t2/n2
    t2=t2+d*d2
    #'''
    #print (t2)
    contour=np.array(contour)
    
    contour=contour.astype(np.float32)
    #print(contour)
    contour=cv2.undistortPoints(contour, camera_matrix, dist_coefs,P=camera_matrix)
    x0=camera_matrix[0][2]
    y0=camera_matrix[1][2]
    #print(contour)
    for j in range(len(contour)):
        point=contour[j][0]
        tpoint=[point[0]-x0,point[1]-y0,d]
        tpoint=np.array(tpoint)
        #rpoint=np.dot(tpoint,-rotation_matrix)
        rpoint=np.dot(tpoint,rotation_matrix)
        #print(rpoint)
        #parte di prova
        #f=np.array([0,0,-d])
        #f=np.dot(f,rotation_matrix)

        nc=line_plane_intersection(t2,rpoint,plane_point,plane_normal)
        #nc=[int(nc[0]/10)+2000,int(nc[1]/10)+1500]
        nc=[int(nc[0]/5)+x0,int(nc[1]/5)+y0]
        new_contours.append([nc])
    nc2=[]
    for el in new_contours:
        nc2.append([[int(el[0][0]),int(el[0][1])]])
    approx=np.array(nc2)
    approx = np.array(approx, dtype=np.int32)
    approx = np.ascontiguousarray(approx)
    
    r=mask_outside_polygon(white,approx)
    return r


'''
#code used to check if this work
with open('data.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
camera_matrix=np.array(datat["camera_matrix"])
dist_coefs=np.array(datat["dist_coefs"])

with open('matrix.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
rotation_matrix=np.array(datat["rotation_matrix"])
translation_vectors=np.array(datat["translation_vectors"])

with open('contours.json', 'r') as file:
    contours = json.load(file)

#provo a far qualcosa dopo si può scrivere maglio
i=4
r=rotation_matrix[i]
t=translation_vectors[i]
#print(contours)
c=contours[i]
r_t=-np.transpose(r)
#print(r_t)

black=np.zeros((3000,4000,3))
black2=np.zeros((3000,4000,1),dtype=np.uint8)
white=255-black2
new_contours=[]
plane_normal=[0,0,1]
plane_point=[0,0,0]
d=camera_matrix[0][0]

t2=[t[0][0],t[1][0],t[2][0]]
print (t2)
for j in range(len(c)):
    point=c[j][0]
    tpoint=[point[0]-2000,point[1]-1500,d]
    tpoint=np.array(tpoint)
    rpoint=np.dot(tpoint,-r)
    #print(rpoint)
    nc=line_plane_intersection(t2,rpoint,plane_point,plane_normal)
    nc=[int(nc[0]/10),int(nc[1]/10)]
    new_contours.append([nc])

print(new_contours)
nc2=[]
for el in new_contours:
    nc2.append([[int(el[0][0]),int(el[0][1])]])
approx=np.array(nc2)
l=approx.shape[0]
print([approx])
for i in range(l-1):
    cv2.line(black,(approx[i,0,0],approx[i,0,1]),(approx[i+1,0,0],approx[i+1,0,1]),(0,255,0),2)
cv2.line(black,(approx[l-1,0,0],approx[l-1,0,1]),(approx[0,0,0],approx[0,0,1]),(0,255,0),2)


#plt.imshow(closing2, cmap='gray', vmin=0, vmax=255)
plt.imshow(black)
plt.show()

approx = np.array(approx, dtype=np.int32)
approx = np.ascontiguousarray(approx)

r=mask_outside_polygon(white,approx)


r2 = cv2.cvtColor(r, cv2.COLOR_GRAY2BGR)
plt.imshow(r2)
plt.show()
#'''



