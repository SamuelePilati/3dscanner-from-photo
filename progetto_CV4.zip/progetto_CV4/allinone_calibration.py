import cv2
import numpy as np
from matplotlib import pyplot as plt
import json

from p_bin_corner import get_points
'''
In this part of the program we use the function get_points to get the image position and the corresponding real position of the 
corners for every image, then we call the calibrate camera function with those points in order to find the position from 
where the photos where been taken.

Then it writes in json files rotation and translation vector of the camera respecti with the world reference frame, the camera
estrinsic(?) and wheter this process whas successfull or not
'''

n=31
img_names = ["img3/" + str(i) + ".jpg" for i in range(1,n+1)]
obj_points=[]
img_points=[]
riusciti=[]
for i in range(0,n):
    print(i+1)
    imgt=cv2.imread(img_names[i])

    try:
        imgpt, objpt, r=get_points(imgt)
        if(r==1):
            img_points.append(imgpt)
            obj_points.append(objpt)
            riusciti.append(0)
        else:
            riusciti.append(1)
    #'''
    except:
        print("something went wrong in later")
        riusciti.append(1)
    #'''

h, w = cv2.imread(img_names[0], cv2.IMREAD_GRAYSCALE).shape[:2]

rms, camera_matrix, dist_coefs, rvecs, tvecs = cv2.calibrateCamera(obj_points, img_points, (w, h), None, None)

'''
data={"camera_matrix":camera_matrix.tolist(), "dist_coefs":dist_coefs.tolist()}
with open("data.json", "w") as f:
    json.dump(data, f)
#'''


print("\nRMS:", rms)
print("camera matrix:\n", camera_matrix)
print("distortion coefficients: ", dist_coefs.ravel())
#print("Rotation vectors:", rvecs)
#print("translation vectors", tvecs)

#inserire dati in file.json
data={ "riusciti":riusciti}
with open("riusciti.json", "w") as f:
    json.dump(data, f)

data={"camera_matrix":camera_matrix.tolist(), "dist_coefs":dist_coefs.tolist()}
with open("calibration.json", "w") as f:
    json.dump(data, f)

rvecs=np.array(rvecs)
tvecs=np.array(tvecs)
data={"rotation_vectors":rvecs.tolist(), "translation_vectors":tvecs.tolist()}
with open("position.json", "w") as f:
    json.dump(data, f)

