import cv2
import numpy as np
from matplotlib import pyplot as plt
import json
import pyvista as pv

from get_lines import obtain_shadow

with open('calibration.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
camera_matrix=np.array(datat["camera_matrix"])
dist_coefs=np.array(datat["dist_coefs"])

with open('riusciti.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
riusciti=datat["riusciti"]

with open('contours.json', 'r') as file:
    contours = json.load(file)

with open('position.json', 'r', encoding='utf-8') as file:
    datat = json.load(file)
rvecs=np.array(datat["rotation_vectors"])
tvecs=np.array(datat["translation_vectors"])

translation_vectors=[]
rotation_matrix=[]
l=len(rvecs)
for i in range(l):
    R, _ = cv2.Rodrigues(rvecs[i])

    R_T = np.transpose(R)
    camera_position = -np.dot(R_T, tvecs[i])
    translation_vectors.append(camera_position)
    rotation_matrix.append(R_T)

translation_vectors=np.array(translation_vectors)
rotation_matrix=np.array(rotation_matrix)    

def final_shadow_points(z, translation_vectors, rotation_matrix, contours, camera_matrix, dist_coefs, n_images):
    '''
    returns an and of all the shadows obtain with the different photos.
    '''
    #n0=np.linalg.norm(translation_vectors[0])
    t0=translation_vectors[0]

    img1=obtain_shadow(rotation_matrix[0], t0, contours[0], z, camera_matrix, dist_coefs)
    img2=np.uint16(img1)
    i=0
    for k in range(n_images):
        if(riusciti[k]==0):
            t=translation_vectors[i]#+translation_vectors[0]*3000/n0
            imgt=obtain_shadow(np.transpose(rotation_matrix[i]), t, contours[k], z, camera_matrix, dist_coefs)
            i=i+1
            #kernel = np.ones((21,21),np.uint8)
            #imgt=cv2.dilate(imgt,kernel)
            img2=img2+np.uint16(imgt)
    img2=img2/(i+1)
    img2=np.uint8(img2)
    img2=cv2.blur(img2,(21,21))
    ret,thresh = cv2.threshold(img2,240,255,cv2.THRESH_BINARY)#220
    c, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    return c


'''
z=-1000
n0=np.linalg.norm(translation_vectors[0])
t0=translation_vectors[0]#+translation_vectors[0]*3000/n0
#img1=obtain_shadow(rotation_matrix[0], translation_vectors[0], contours[0], z, camera_matrix)
img1=obtain_shadow(rotation_matrix[0], t0, contours[0], z, camera_matrix, dist_coefs)
img2=img1
img3=np.uint16(img1)
plt.imshow(img1)
plt.show()
i=0
for k in range(31):
    #n=np.linalg.norm(translation_vectors[k])
    if(riusciti[k]==0):
        t=translation_vectors[i]#+translation_vectors[0]*3000/n0
        #imgt=obtain_shadow(rotation_matrix[k], translation_vectors[k], contours[k], z, camera_matrix)
        imgt=obtain_shadow(np.transpose(rotation_matrix[i]), t, contours[k], z, camera_matrix, dist_coefs)
        #imgt=obtain_shadow(rotation_matrix[i], t, contours[k], z, camera_matrix)
        i=i+1
        plt.imshow(imgt)
        plt.show()
        kernel=kernel = np.ones((21,21),np.uint8)
        imgt=cv2.dilate(imgt,kernel)
        img1=cv2.bitwise_and(img1, img1, mask=imgt)
        img2=cv2.bitwise_or(img2,imgt)
        img3=img3+np.uint16(imgt)
#
plt.imshow(img2)
plt.show()
plt.imshow(img1)
plt.show()

img3=img3/(i+1)

img3=np.uint8(img3)
plt.imshow(img3)
plt.show()

ret,thresh = cv2.threshold(img3,140,255,cv2.THRESH_BINARY)
plt.imshow(thresh)
plt.show()
kernel=kernel = np.ones((21,21),np.uint8)
opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel)
plt.imshow(closing)
plt.show()
#'''


